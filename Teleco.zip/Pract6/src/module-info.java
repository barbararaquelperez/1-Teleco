module Pract6 {
}