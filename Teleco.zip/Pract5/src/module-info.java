module Pract5 {
}