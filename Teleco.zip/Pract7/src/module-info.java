module Pract7 {
}